﻿CREATE TABLE Teams (
    team_id INT PRIMARY KEY,
    team_name NVARCHAR(50) NOT NULL,
    home_ground NVARCHAR(50)
);

