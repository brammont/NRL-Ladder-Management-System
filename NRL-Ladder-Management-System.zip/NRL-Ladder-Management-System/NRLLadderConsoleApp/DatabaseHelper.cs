﻿using System.Data.SqlClient;

public class DatabaseHelper
{
    private const string connectionString = "Server=(localdb)\\mssqllocaldb;Database=NRLLadder;Trusted_Connection=True;";

    public SqlConnection GetConnection()
    {
        return new SqlConnection(connectionString);
    }
}

